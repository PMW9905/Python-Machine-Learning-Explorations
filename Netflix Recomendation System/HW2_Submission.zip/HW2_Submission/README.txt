Parker Whitehead
pmw180000@utdallas.edu

Question 1 and Question 2 are titled hw2a and hw2b respectively.

The pdfs in this folder contain the output of the jupyter notebooks.

Inside the Code, Data, and Notebooks folder, you can find my sourcecode for the Collaborative Filtering
Along with the 2 notebooks.

If you have any problems, please contact me at pmw180000@utdallas.edu